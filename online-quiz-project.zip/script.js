function calculateScore() {
    let score = 0;

    const answers = {
        q1: "a",
        q2: "b",
        q3: "b"
    };

    for (let question in answers) {
        let selected = document.querySelector(`input[name="${question}"]:checked`);
        if (selected && selected.value === answers[question]) {
            score++;
        }
    }

    document.getElementById("result").innerHTML =
        `Your Score: ${score} / 3`;
}
